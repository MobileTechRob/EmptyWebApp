﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;
using System.IO;

namespace WindowsFormsApp1
{    
    public partial class Form1 : Form
    {
        [XmlRoot("MySettings")]
        public class MySettings
        {
            [XmlElement("ClientX")]
            public int clientX { get; set; }

            [XmlElement("ClientY")]
            public int clientY { get; set; }

            [XmlArray("ScreenCollection")]
            public List<Screen> Screens { get; set; }

            public MySettings()
            {
                Screens = new List<Screen>();
            }
        }
                
        public class Screen
        {
            [XmlElement]
            public string ScreenNumber { get; set; }

            [XmlElement]
            public string StockNumber { get; set; }

            [XmlElement]
            public string Make { get; set; }

            [XmlElement]
            public string Model { get; set; }

        }

        public Form1()
        {
            InitializeComponent();
           
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            StreamReader rdr = new StreamReader("C:\\XmlFiles\\test.xml");
            XmlSerializer ser = new XmlSerializer(typeof(MySettings));

            MySettings d = (MySettings)ser.Deserialize(rdr);

            rdr.Close();



        }

        private void button1_Click(object sender, EventArgs e)
        {
            MySettings mysettings = new MySettings();

            mysettings.clientX = 135;
            mysettings.clientY = 112;

            Screen s = new Screen();
            s.ScreenNumber = "Screen 1";
            s.Make = "a make";
            s.Model = "a model";
            s.StockNumber = "a stock number";

            mysettings.Screens.Add(s);

            s = new Screen();
            s.ScreenNumber = "Screen 2";
            s.Make = "a make 2 ";
            s.Model = "a model 2";
            s.StockNumber = "a stock number 2";

            mysettings.Screens.Add(s);

            StreamWriter wtr = new StreamWriter("C:\\XmlFiles\\test.xml");
            XmlSerializer ser = new XmlSerializer(typeof(MySettings));

            ser.Serialize(wtr, mysettings);

            wtr.Close();
        }
    }
}
